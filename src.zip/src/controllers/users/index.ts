import { RequestHandler } from "express";
import { getUsersQuery, getUserQuery, registerUserQuery } from "../../queries/userQueries";

type GetUsers = RequestHandler<{ id?: string }>;
export const getUsers: GetUsers = async (req, res) => {
  const data =
    req.params.id !== undefined ? await getUserQuery(+req.params.id) : await getUsersQuery();

  res.status(200).send({ status: "ok", data });
};

type RegisterUser = RequestHandler<
  {}, // Route parameters (none in this case)
  {}, // Response body (we're not specifying a custom response type here)
  { username: string; email: string; password: string } // Request body
>;
//Add middleware to ensure the body properties are there.
export const registerUser: RegisterUser = async (req, res) => {
  const { email, password, username } = req.body;
  try {
    const result = await registerUserQuery(email, password, username);

    if (result === null) throw new Error(`Register User: ${result}`);

    if (result === "DUPLICATE_ENTRY") {
      res.status(409).send({ status: result });
      return;
    }

    res.status(201).send({ status: "user registered " });
  } catch (error) {
    console.error(error);
    res.status(500).send({ status: "Failed to register user" });
  }
};
