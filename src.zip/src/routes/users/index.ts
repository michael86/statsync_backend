import { Router } from "express";
import { getUsers, registerUser } from "../../controllers/users";
import { registerUserValidation } from "../../middleware/users";

const router = Router();

router.get("/get/:id?", getUsers);
router.post("/register", registerUserValidation, registerUser);

export default router;
