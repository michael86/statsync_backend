import { RequestHandler } from "express";

export const registerUserValidation: RequestHandler = (req, res, next) => {
  const { email, password, username } = req.body;

  if (!email || !password || !username) {
    res.status(400).send({ status: "invalid query" });
    return;
  }

  //add more validation here to ensure password matches requirem,ents and email is email and so on
  next();
};
